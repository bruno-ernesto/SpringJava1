package com.example.h2.api.repositorio;
import com.example.h2.api.modelo.Language;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RepositorioLanguage extends JpaRepository<Language,Long> {
}
